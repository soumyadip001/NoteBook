import React from "react"

import classes from "./Parent.module.css"

const parent = (props) => {
    const ListClassUL = "list-group " + classes.ParentCategoryList
    const ListClassLI = "list-group-item d-flex justify-content-between align-items-center " + classes.ParentCategoryListLI
    return (
        <div className={classes.ParentCategory}>
            <ul className={ListClassUL}>
                <li className={ListClassLI}>
                    <a href="/#" className={classes.ParentLink}>All Notes</a>
                    <span className="badge badge-pill">245</span>
                    
                </li>
                <li className={ListClassLI}>
                    <a href="/#" className={classes.ParentLink}>Note Books</a>
                    <span className="badge badge-pill">30</span>
                </li>
                <li className={ListClassLI}>
                    <a href="/#" className={classes.ParentLink}>Tutorial</a>
                    <span className="badge badge-pill">15</span>
                </li>
                <li className={ListClassLI}>
                    <a href="/#" className={classes.ParentLink}>Tags</a>
                    <span className="badge badge-pill">12</span>
                </li>
                <li className={ListClassLI}>
                    Advanced
                </li>
                <li className={ListClassLI}>
                    Intermediate
                </li>
                <li className={ListClassLI}>
                    Basic
                </li>
            </ul>
        </div>
    )
}

export default parent