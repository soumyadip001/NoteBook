import React from 'react';
import './App.css';

import Note from "./Components/Note"

function App() {
  return (
    <div className="App">
      <Note />
    </div>
  );
}

export default App;
