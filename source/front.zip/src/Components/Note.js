import React, {Component} from "react"
import axios from "axios"

import Layout from "../Layout/Layout"

class Note extends Component {

    state = {
        viewEditSection: true,
        viewNoteViewSection: false,
        textAreaContent: '',
        questionTitle: '',
        selectedCategory: 'node'
    }

    showCreateNoteSection = () => {
        this.setState({
            ...this.state,
            viewEditSection: true,
            viewNoteViewSection: false
        })
    }

    handleChangeTextArea = (e) => {
        const content = e.target.value
        this.setState({
            textAreaContent: content
        })
    }

    handleChangeQuestionTitle = (e) => {
        const title = e.target.value
        this.setState({
            questionTitle: title
        })
    }

    handleSaveNote = () => {
        const qTitle = this.state.questionTitle
        const qContent = this.state.textAreaContent
        const category = this.state.selectedCategory

        // check the file name
        if (!this.isValid(qTitle)) {
            // remove special chanracters \ / : * ? " < > |
            // remove starting .
            console.log("File name is wrong!");
        }
        
        const postData = {
            title: qTitle, 
            content: qContent, 
            category: category
        }

        axios.post('http://127.0.0.1:8000/notes', postData)
            .then((response) => {
                console.log(response.data)
            })
            .catch((error) => {
                console.log(error);
            });
    
    }

    isValid = (fname) => {
        var rg1= /^[^\\/:\*\?"<>\|]+$/;
        var rg2=/^\./; 
        var rg3=/^(nul|prn|con|lpt[0-9]|com[0-9])(\.|$)/i; 
        return function isValid(fname){
          return rg1.test(fname)&&!rg2.test(fname)&&!rg3.test(fname);
        }
    }

    render() {
        return (
            <Layout showEditSection={this.state.viewEditSection}
                showViewSection={this.state.viewNoteViewSection}
                textAreaContent={this.state.textAreaContent}
                titleContent={this.state.questionTitle}
                handleCreteNote={this.showCreateNoteSection}
                handleChangeTextArea={this.handleChangeTextArea}
                handleChangeQuestionTitle={this.handleChangeQuestionTitle}
                handleSaveNote={this.handleSaveNote} />
        )
    }
}

export default Note